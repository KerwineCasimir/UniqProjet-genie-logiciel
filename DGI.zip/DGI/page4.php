<?php 
error_reporting(E_ALL); 
ini_set("display_errors", 1);

if(isset($_POST['insert']))
{
    $hostname = "localhost";
    $username = "root";
    $password ="";
    $dbname = "dgi";


 $nom = $_POST['nom'];
$prenom =$_POST['prenom'];
$telephone =$_POST['telephone'];
$email = $_POST['email'];
$naissance = $_POST['naissance'];
$genre = $_POST['genre'];
$statut=$_POST['statut'];
$emploi =$_POST['emploi'];
$nif = rand(50000,1000000);




    $con = mysqli_connect($hostname,$username,$password,$dbname);
    
    $query = "INSERT INTO matricule(nom,prenom,naissance,telephone,email,genre,emploi,statut,nif) VALUES('$nom','$prenom','$naissance','$telephone','$email','$genre','$emploi','$statut','$nif')";
    $result = $con->query($query) or die($con->error);

    if($result)
    {
        echo "Data inserted";
        echo " the nif is :$nif";
    } else{
        echo 'Data not inserted';
    }
   
   $con->close();
}

