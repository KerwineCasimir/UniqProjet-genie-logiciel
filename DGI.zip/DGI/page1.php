<?php
echo " <style>
body {
    background-color:#ccf;
    letter-spacing:.1em;

  }


table {
    width: 50%;
    border: 1px solid black;
    border-collapse: separate;
     border-spacing: 5px 8px;
  }
  
  th {
    height: 50px;
    text-align: left;
    padding: 15px;
    border-bottom: 1px solid #ddd;
    background-color: #4CAF50;
  color: white;
  }
  td {
    height: 50px;
    vertical-align: bottom;
    padding: 12px;
    border-bottom: 1px solid #ddd;
  }
  tr:hover {background-color: #f5f5f5;}


caption {
font-family: sans-serif;
}



 </style>
";
error_reporting(E_ALL); 
ini_set("display_errors", 1);

if(isset($_POST['Envoyer'])){

$user = $_POST['user'];
$pass = $_POST['pass'];

$hostname = "localhost";
    $username = "root";
    $password ="";
    $dbname = "dgi";
    $con = mysqli_connect($hostname,$username,$password,$dbname);

if($con->connect_error){
    die("Connection failed:" .$con->connect_error);
}

$sql="SELECT *  FROM contribuable WHERE user ='$user' and  pass='$pass'";

$result = $con->query($sql);
if($result->num_rows > 0){
    echo "
    <h1><strong>Bienvenue :$user</strong></h1>

    

    
        <table>
   <tr><th><strong>User</strong></th><th><strong>Nom</strong></th><th><strong>Prenom</strong></th><th><strong>Date de naissance</strong></th><th><strong>Genre</strong></th><th><strong>Telephone</strong></th></tr><br></br>
   
   "
   
   ;
    while($row = $result->fetch_assoc()){
   
        echo " 
        <td>".$row["user"]."</><td>".$row["Nom"]."</td><td> ".$row["Prenom"]."</td><td>".$row["Date_de_naissance"]."</td><td>".$row["genre"]."</td><td>".$row["telephone"]."</td> ";
    }
    echo "</table> <br></br>";
    echo "<a href=compte.php>mes infos</a> <br></br>" ;
    echo "<a href=logout.php>Logout</a>";    
    
 }
}  else {
    header('Location:page1.html');
    
}

$con->close();

?>