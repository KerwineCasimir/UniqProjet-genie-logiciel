<?php 
error_reporting(E_ALL); 
ini_set("display_errors", 1);

if(isset($_POST['insert']))
{
    $hostname = "localhost";
    $username = "root";
    $password ="";
    $dbname = "dgi";

 $nom = $_POST['nom'];
$prenom =$_POST['prenom'];
$telephone =$_POST['telephone'];
$email = $_POST['email'];
$nif = $_POST['nif'];
$naissance = $_POST['naissance'];



    $con = mysqli_connect($hostname,$username,$password,$dbname);
    
    $query = "INSERT INTO timbre_passeport(nom,prenom,Date_de_naissance,telephone,email,nif) VALUES('$nom','$prenom','$naissance','$telephone','$email','$nif')";
    $result = $con->query($query) or die($con->error);

    if($result)
    {
        echo "Data inserted ";
        header('Location: page5.html');
    } else{
        echo 'Data not inserted';
    }
   
   $con->close();
}




?>