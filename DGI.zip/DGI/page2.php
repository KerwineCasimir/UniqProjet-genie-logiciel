<?php 
error_reporting(E_ALL); 
ini_set("display_errors", 1);

if(isset($_POST['insert']))
{
    $hostname = "localhost";
    $username = "root";
    $password ="";
    $dbname = "dgi";

$user= $_POST['user'];
 $nom = $_POST['nom'];
$prenom =$_POST['prenom'];
$telephone =$_POST['telephone'];
$email = $_POST['email'];
$naissance = $_POST['naissance'];
$genre = $_POST['genre'];
$pass = $_POST['pass'];
echo $telephone;



    $con = mysqli_connect($hostname,$username,$password,$dbname);
    
    $query = "INSERT INTO contribuable(user,Nom,Prenom,Date_de_naissance,telephone,Email,genre,pass) VALUES('$user','$nom','$prenom','$naissance','$telephone','$email','$genre','$pass')";
    $result = $con->query($query) or die($con->error);

    if($result)
    {
        echo "Data inserted";
    } else{
        echo 'Data not inserted';
    }
   
   $con->close();
}




?>