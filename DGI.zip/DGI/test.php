<?php
echo " <style>
body {
    background-color:#ccf;
    letter-spacing:.1em;

  }


table {
    width: 50%;
    border: 1px solid black;
    border-collapse: separate;
     border-spacing: 5px 8px;
  }
  
  th {
    height: 50px;
    text-align: left;
    padding: 15px;
    border-bottom: 1px solid #ddd;
    background-color: #4CAF50;
  color: white;
  }
  td {
    height: 50px;
    vertical-align: bottom;
    padding: 12px;
    border-bottom: 1px solid #ddd;
  }
  tr:hover {background-color: #f5f5f5;}


caption {
font-family: sans-serif;
}


#menu ul{
    margin:0;
    padding:0;
    line-height:30px;
    
}
#menu li{
    list-style:none;
    float:right;
    position:relative;
    background-color:#C0C0C0;
}
#menu ul li a
{
    color:#000;
    test-decoration:none;
    width:150px;
    height:30px;
    display:block;
    text-align:center;
    border:1px solid #000;

}
#menu ul ul{
    position:absolute;
    top:30px;
    visibility:hidden;

}
#menu ul li:hover ul{
    visibility:visible;
}
#menu li:hover
{
background-color:#E9967A;
}
#menu ul li ul a:hover{
    color:#fff;
    backgroung-color:#FFA07A;
}

 </style>
";
error_reporting(E_ALL); 
ini_set("display_errors", 1);


if(isset($_POST['Envoyer'])){

$user = $_POST['user'];
$pass = $_POST['pass'];

$hostname = "localhost";
    $username = "root";
    $password ="";
    $dbname = "dgi";
    $con = mysqli_connect($hostname,$username,$password,$dbname);

if($con->connect_error){
    die("Connection failed:" .$con->connect_error);
}

$sql="SELECT *  FROM contribuable WHERE user ='$user' and  pass='$pass'";

$result = $con->query($sql);
if($result->num_rows > 0){
    echo "
    <h1><strong>Bienvenue :$user</strong></h1>
    <div id =menu>
    <ul>
    <li>
    <a href=#>Services</a>
    <ul>
     <li><a href=page4.html>Matricule</a></li>
    <li><a href=page5.html>Timbre passeport</a></li>
    <li><a href=page9.html>impot sur le revenu</a></li>
    <li><a href=page8.html>Impot locatif</a></li>
    <li><a href=page10.html>Legalisation piece</a></li>
    <li><a href=page11.html>Permis d'arme</a></li>
    <li><a href=page7.html>Acte de mariage</a></li>
    
    </ul>
    </li>
    </ul>
    <ul>
    <li><a href=logout.php>Logout</a></li></ul>
    </div>
   
    
        <table>
   <tr><th><strong>User</strong></th><th><strong>Nom</strong></th><th><strong>Prenom</strong></th><th><strong>Date de naissance</strong></th><th><strong>Genre</strong></th><th><strong>Telephone</strong></th></tr><br></br>
   
   "
   
   ;
    while($row = $result->fetch_assoc()){
   
        echo " 
        <td>".$row["user"]."</><td>".$row["Nom"]."</td><td> ".$row["Prenom"]."</td><td>".$row["Date_de_naissance"]."</td><td>".$row["genre"]."</td><td>".$row["telephone"]."</td> ";
    }
    echo "</table> <br></br>";
    
    
    
 }
}  else {
    //header('location : page1.html');
    echo"<meta http-equiv=Location content=http://localhost/DGI/page1.html>";

}

$con->close();

?>