<?php 
error_reporting(E_ALL); 
ini_set("display_errors", 1);

if(isset($_POST['Envoyer']))
{
    $hostname = "localhost";
    $username = "root";
    $password ="";
    $dbname = "dgi";


 $nom = $_POST['nom'];
$prenom =$_POST['prenom'];
$telephone =$_POST['telephone'];
$email = $_POST['email'];
$naissance = $_POST['naissance'];
$genre = $_POST['genre'];
$nif = $_POST['nif'];





    $con = mysqli_connect($hostname,$username,$password,$dbname);
    
    $query = "INSERT INTO acte_de_mariage(nom,prenom,naissance,telephone,email,genre,nif) VALUES('$nom','$prenom','$naissance','$telephone','$email','$genre','$nif')";
    $result = $con->query($query) or die($con->error);

    if($result)
    {
        echo "Data inserted " ;
    } else{
        echo 'Data not inserted';
    }
   
   $con->close();
}

